#!/usr/bin/env node
// Cài bộ CI Auto-Fix vào một project thật. CHỈ COPY FILE — không chạy git, không commit, không push.
//
//   node scripts/ci-autofix/install.mjs --target <project> [--profile <tên|đường-dẫn>] [--runner <label>] [--force] [--dry-run]
//
//   --profile  tên file trong .claude/skills/ci-auto-fix/references/profiles/ (vd agentic-e2e-v2)
//              hoặc đường dẫn file .md → chép thành references/project_profile.md của project đích
//   --runner   label runner cho ai-autofix.yml (mặc định giữ "self-hosted"); phải trùng runs-on của workflow test
//   --force    ghi đè file đã có (mặc định giữ nguyên file của project)
//   --dry-run  chỉ in ra sẽ làm gì
import { cpSync, existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, statSync, appendFileSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const SRC = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (!a.startsWith('--')) continue;
  const next = process.argv[i + 1];
  args[a.slice(2)] = next && !next.startsWith('--') ? (i++, next) : true;
}
const fail = (m) => (console.error(`LỖI: ${m}`), process.exit(1));
if (!args.target || args.target === true) fail('Thiếu --target <đường-dẫn-project>');
const TARGET = resolve(args.target);
if (!existsSync(join(TARGET, 'package.json'))) fail(`${TARGET} không giống project Node (thiếu package.json)`);
const force = !!args.force;
const dry = !!args['dry-run'];

// Những gì được chép: 4 agent · skill ci-auto-fix + 2 skill ci-fixer đọc theo ci-fixer đọc theo · rule locator · script · workflow
const ITEMS = [
  '.claude/agents/ci-failure-fetcher.md',
  '.claude/agents/ci-failure-classifier.md',
  '.claude/agents/ci-fixer.md',
  '.claude/agents/ci-fix-reporter.md',
  '.claude/skills/ci-auto-fix',
  '.claude/skills/analyze-flaky-tests',
  '.claude/skills/skills-locator-agent',
  '.claude/rules/locator_strategy.md',
  'scripts/ci-autofix/ci_autofix.mjs',
  'scripts/ci-autofix/README.md',
  '.github/workflows/ai-autofix.yml',
];

const files = (p) => (statSync(p).isDirectory() ? readdirSync(p).flatMap((n) => files(join(p, n))) : [p]);
const done = { copied: [], kept: [] };

function put(relDest, content) {
  const dest = join(TARGET, relDest);
  if (existsSync(dest) && !force) return done.kept.push(relDest);
  done.copied.push(relDest);
  if (dry) return;
  mkdirSync(dirname(dest), { recursive: true });
  writeFileSync(dest, content);
}

for (const item of ITEMS) {
  const abs = join(SRC, item);
  if (!existsSync(abs)) fail(`Thiếu nguồn ${item}`);
  for (const f of files(abs)) {
    const rel = relative(SRC, f).replaceAll('\\', '/');
    let content = readFileSync(f);
    if (rel === '.github/workflows/ai-autofix.yml' && args.runner && args.runner !== true) {
      content = content.toString('utf8').replaceAll('runs-on: self-hosted', `runs-on: ${args.runner}`);
    }
    put(rel, content);
  }
}

// Profile riêng của project
const PROFILE_DEST = '.claude/skills/ci-auto-fix/references/project_profile.md';
if (args.profile && args.profile !== true) {
  const byName = join(SRC, '.claude/skills/ci-auto-fix/references/profiles', `${args.profile}.md`);
  const src = existsSync(byName) ? byName : resolve(args.profile);
  if (!existsSync(src)) fail(`Không tìm thấy profile "${args.profile}"`);
  put(PROFILE_DEST, readFileSync(src));
} else if (!existsSync(join(TARGET, PROFILE_DEST))) {
  console.warn('⚠️  Chưa có project_profile.md — chép project_profile.template.md thành project_profile.md rồi điền cho project này.');
}

// .gitignore: clone tạm + thư mục báo cáo AI
const gi = join(TARGET, '.gitignore');
const giText = existsSync(gi) ? readFileSync(gi, 'utf8') : '';
const missing = ['.ci-autofix-work/', 'claude-report/'].filter((l) => !giText.split(/\r?\n/).includes(l));
if (missing.length && !dry) appendFileSync(gi, `${giText.endsWith('\n') || !giText ? '' : '\n'}\n# CI Auto-Fix\n${missing.join('\n')}\n`);

console.log(`${dry ? '[dry-run] ' : ''}Cài vào ${TARGET}`);
console.log(`  chép ${done.copied.length} file${done.kept.length ? ` · giữ nguyên ${done.kept.length} file đã có (dùng --force để ghi đè)` : ''}`);
if (missing.length) console.log(`  .gitignore: thêm ${missing.join(', ')}`);
console.log('Không chạy git. Việc còn lại (cần quyền repo): xem scripts/ci-autofix/README.md mục "Cài vào project thật".');
