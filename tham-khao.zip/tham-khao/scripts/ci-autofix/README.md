# CI Auto-Fix — AI tự fix lỗi test trên CI

Quy trình, subagent và guardrail: [`/ci-auto-fix`](../../.claude/skills/ci-auto-fix/SKILL.md) · [hợp đồng & guardrail](../../.claude/skills/ci-auto-fix/references/contract.md). File này chỉ nói **cài đặt và vận hành**.

## Luồng tổng thể

```
GitHub Actions "Playwright Tests" kết thúc
   │  workflow_run (completed)
   ▼
.github/workflows/ai-autofix.yml ── cài Claude Code ── claude -p "dùng skill ci-auto-fix …"
   │
   ├─ B1  ci-failure-fetcher     tải report + log CI + log/screenshot/video ReportPortal
   ├─ B2  ci-failure-classifier  gom cụm  →  ci-fixer × N (song song, mỗi batch 1 worktree)
   ├─ B3  push nhánh ai-fix/run-<id>  →  workflow_dispatch chạy lại spec đã sửa
   ├─ B5  ci-fix-reporter        ai_fix_report.md + PR cho tester
   └─ B4  NGƯỜI confirm & merge  (AI không có đường nào tới nhánh gốc)
   ▲
   └─ run chạy lại fail → vào lại vòng (tối đa maxAttempts) · xanh → FINALIZE (comment PR)
```

## Cài vào project thật

```bash
node scripts/ci-autofix/install.mjs --target <đường-dẫn-project> --profile <doda-e2e|agentic-e2e-v2> [--runner <label>] [--dry-run]   # chỉ COPY, không đụng git
```

Chép: 4 agent · skill `ci-auto-fix` + 2 skill `ci-fixer` đọc theo (`analyze-flaky-tests`, `skills-locator-agent`) · `ci_autofix.mjs` · `.github/workflows/ai-autofix.yml`. File đã có thì giữ nguyên (muốn ghi đè: `--force`).

Sau đó **tự làm** (cần quyền repo):

1. Sửa `workflows:` trong `ai-autofix.yml` cho khớp `name:` thật của workflow test (project mẫu: `Playwright Tests`, `Playwright Tests Scheduled Execution`).
2. Thêm **Repository secrets**: `ANTHROPIC_API_KEY` · (khuyến nghị) `AI_FIX_GH_TOKEN` — PAT / GitHub App quyền `contents`, `pull-requests`, `actions`; cần để vòng lặp tự động chạy (xem bảng dưới). `REPORT_PORTAL_*` và secrets môi trường test đã có sẵn ở project.
3. Bật **Settings → Actions → General → Allow GitHub Actions to create and approve pull requests**.
4. **Branch protection** cho nhánh mặc định: bắt buộc review + status check → đảm bảo B4 là người.
5. Commit `ai-autofix.yml` lên **nhánh mặc định** — `workflow_run` chỉ chạy từ file nằm ở nhánh mặc định.
6. Tạo label `ai-fix` và `needs-tester-review` (tuỳ chọn; thiếu label thì PR vẫn tạo được).

## Chạy tay để thử (không cần chờ CI fail)

```bash
export GH_TOKEN=… REPORT_PORTAL_ENDPOINT=… REPORT_PORTAL_API_KEY=…
node scripts/ci-autofix/ci_autofix.mjs fetch    --repo owner/name --run-id 123456789
node scripts/ci-autofix/ci_autofix.mjs classify --in claude-report/ci-autofix/run_123456789/failures.json
# hoặc trong Claude Code:  /ci-auto-fix repo=owner/name runId=123456789
```

## Điều cần kiểm chứng trên project thật (chưa chạy được ở repo demo)

| Hạng mục | Vì sao cần kiểm |
|---|---|
| `actions/upload-artifact@v3` trong `playwright.yml` của project mẫu | v3 đã bị GitHub.com ngừng; nếu runner là github.com, artifact `playwright-report` không được tạo → fetch rơi về nguồn ReportPortal. Nên nâng lên `@v4` |
| `retention-days: 2` của artifact report | Quá 2 ngày artifact hết hạn → script chỉ còn ReportPortal. Cân nhắc tăng |
| Link ReportPortal trong log CI | Script tìm theo mẫu `…/ui/#<project>/launches/all/<id>` (workflow mẫu đã in ra). Đổi định dạng link → không tìm thấy launch |
| API ReportPortal v1 | Đường dẫn `item`/`log`/`data` theo ReportPortal 5.x; bản khác có thể lệch tham số lọc |
| Tên input của workflow test | Skill truyền `environment` và `testFile` (đúng project mẫu). Workflow khác tên input → GitHub trả 422 |
| Runner `self-hosted` + container | Cần Node ≥ 18, `git`, `unzip` hoặc `tar`, truy cập mạng tới `github.com` và ReportPortal |
| Vòng lặp tự động (FIX lại / FINALIZE) | Push bằng `GITHUB_TOKEN` không kích hoạt workflow (đã xử lý bằng `workflow_dispatch`), nhưng run do `GITHUB_TOKEN` dispatch có thể **không** kích hoạt `workflow_run` khi kết thúc → vòng lặp dừng sau lần chạy lại đầu tiên. Đặt secret `AI_FIX_GH_TOKEN` (PAT hoặc GitHub App) để chắc chắn; kiểm chứng ở lần chạy thật đầu tiên |
| Chạy song song | Mỗi `ci-fixer` mở một Chromium (slowMo, video) đánh vào cùng môi trường test, có thể cùng tài khoản test → lần đầu dùng `maxParallel=2`, theo dõi CPU/RAM runner và lỗi phiên đăng nhập chồng nhau trước khi tăng |
| Chi phí | Mỗi lần CI fail = 1 phiên Claude + N subagent. Giới hạn bằng `maxParallel`, `maxAttempts`, `--max-turns`, và lọc `workflows:` |

## Bảo mật

- Token/API key chỉ đi qua biến môi trường; script không ghi chúng vào file. `ci_autofix.mjs clone|push` truyền token qua `GIT_CONFIG_*` env của tiến trình con — không nằm trong argv, URL remote hay `.git/config`
- Push **chỉ** qua `ci_autofix.mjs push`: chặn cứng nhánh ngoài `ai-fix/*` và mọi kiểu force. Workflow cấm `git push`/`merge`/`rebase`/`reset --hard`/`add -A` bằng `--disallowedTools` và checkout với `persist-credentials: false`
- Ảnh/video tải từ ReportPortal có thể chứa dữ liệu khách hàng thật → nằm trong `claude-report/` (gitignored) và artifact 14 ngày; **đừng** commit
- Nhánh `ai-fix/*` chỉ chứa thay đổi code test; checklist đầu ra chặn thay đổi vào `.github/`, `.env*`, config
