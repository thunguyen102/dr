#!/usr/bin/env node
// CI Auto-Fix helper — không phụ thuộc package ngoài, cần Node >= 18.
//   fetch     tải artifact report + log CI + (nếu có) log/screenshot/video từ ReportPortal -> failures.json
//   classify  gom failures.json thành cụm nguyên nhân -> clusters.json
//   clone     clone repo bằng GH_TOKEN (token không vào argv / .git/config)
//   push      push nhánh — CHỈ ai-fix/*, không bao giờ force
//   open-pr   mở Pull Request cho nhánh ai-fix (KHÔNG merge)
//   comment   comment vào PR
//   dispatch  trigger workflow_dispatch trên nhánh ai-fix để chạy lại CI
// Chi tiết: scripts/ci-autofix/README.md
import { spawnSync } from 'node:child_process';
import { mkdirSync, writeFileSync, readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, basename, extname, resolve } from 'node:path';
import { inflateRawSync } from 'node:zlib';

const [cmd, ...rest] = process.argv.slice(2);
const args = parseArgs(rest);

function parseArgs(list) {
  const out = {};
  for (let i = 0; i < list.length; i++) {
    if (!list[i].startsWith('--')) continue;
    const key = list[i].slice(2);
    const val = list[i + 1] && !list[i + 1].startsWith('--') ? list[++i] : 'true';
    out[key] = key in out ? [].concat(out[key], val) : val;
  }
  return out;
}
const need = (name) => {
  if (!args[name]) fail(`Thiếu --${name}`);
  return args[name];
};
function fail(msg) {
  console.error(`LỖI: ${msg}`);
  process.exit(1);
}
const log = (msg) => console.error(msg);
const writeJson = (file, data) => writeFileSync(file, JSON.stringify(data, null, 2));

// ---------- GitHub REST ----------
const GH_API = process.env.GITHUB_API_URL || 'https://api.github.com';
const GH_TOKEN = process.env.GH_TOKEN || process.env.GITHUB_TOKEN;

async function gh(path, { method = 'GET', body, binary = false } = {}) {
  if (!GH_TOKEN) fail('Thiếu GH_TOKEN / GITHUB_TOKEN');
  const res = await fetch(path.startsWith('http') ? path : `${GH_API}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${GH_TOKEN}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const text = await res.text();
    const err = new Error(`GitHub ${method} ${path} -> ${res.status}: ${text.slice(0, 300)}`);
    err.status = res.status;
    throw err;
  }
  if (res.status === 204) return null;
  return binary ? Buffer.from(await res.arrayBuffer()) : res.json();
}

function extractZip(zipFile, dir) {
  mkdirSync(dir, { recursive: true });
  let r = spawnSync('unzip', ['-o', '-q', zipFile, '-d', dir]);
  if (r.error || r.status !== 0) r = spawnSync('tar', ['-xf', zipFile, '-C', dir]);
  if (r.error || r.status !== 0) fail(`Không giải nén được ${zipFile} (cần unzip hoặc tar)`);
}

function walk(dir, filter) {
  const found = [];
  if (!existsSync(dir)) return found;
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) found.push(...walk(full, filter));
    else if (!filter || filter(full)) found.push(full);
  }
  return found;
}

// ---------- fetch ----------
const RP_LINK = /\/ui\/#([\w-]+)\/launches\/all\/(\d+)/;

async function cmdFetch() {
  const repo = need('repo');
  const runId = need('run-id');
  const out = resolve(args.out || `claude-report/ci-autofix/run_${runId}`);
  mkdirSync(out, { recursive: true });

  const run = await gh(`/repos/${repo}/actions/runs/${runId}`);
  writeJson(join(out, 'run.json'), {
    runId: run.id,
    name: run.name,
    displayTitle: run.display_title,
    headBranch: run.head_branch,
    headSha: run.head_sha,
    conclusion: run.conclusion,
    attempt: run.run_attempt,
    url: run.html_url,
    workflowId: run.workflow_id,
    path: run.path,
  });
  log(`Run ${runId}: ${run.name} / ${run.head_branch} / ${run.conclusion}`);

  // 1. Playwright report artifact
  let reportDir = null;
  const { artifacts } = await gh(`/repos/${repo}/actions/runs/${runId}/artifacts?per_page=100`);
  const art = artifacts.find((a) => /playwright-report|report/i.test(a.name) && !a.expired);
  if (art) {
    const zip = join(out, 'report.zip');
    writeFileSync(zip, await gh(art.archive_download_url, { binary: true }));
    reportDir = join(out, 'report');
    extractZip(zip, reportDir);
    log(`Artifact "${art.name}" -> ${reportDir}`);
  } else {
    log('Không có artifact report (hết hạn hoặc workflow không upload) — dùng ReportPortal làm nguồn chính.');
  }

  // 2. Log CI -> tìm link ReportPortal
  let rp = null;
  try {
    const logZip = join(out, 'ci-logs.zip');
    writeFileSync(logZip, await gh(`/repos/${repo}/actions/runs/${runId}/logs`, { binary: true }));
    const logDir = join(out, 'ci-logs');
    extractZip(logZip, logDir);
    for (const f of walk(logDir, (p) => p.endsWith('.txt'))) {
      const m = RP_LINK.exec(readFileSync(f, 'utf8'));
      if (m) {
        rp = { project: m[1], launchId: m[2], link: m[0] };
        break;
      }
    }
  } catch (e) {
    log(`Không tải được log CI: ${e.message}`);
  }

  // 3. Failures từ report + ReportPortal
  const failures = reportDir ? parseReport(reportDir) : [];
  let rpInfo = null;
  if (rp && process.env.REPORT_PORTAL_ENDPOINT && process.env.REPORT_PORTAL_API_KEY) {
    rpInfo = await fetchReportPortal(rp, out, failures, Boolean(reportDir));
  } else {
    log('Bỏ qua ReportPortal (thiếu link trong log hoặc REPORT_PORTAL_ENDPOINT / REPORT_PORTAL_API_KEY).');
  }

  writeJson(join(out, 'failures.json'), {
    runId: String(runId),
    repo,
    reportDir,
    reportPortal: rpInfo,
    total: failures.length,
    failures,
  });
  console.log(JSON.stringify({ out, failures: failures.length, reportPortal: rpInfo?.link || null }));
}

// ---------- Playwright HTML report nhúng (index.html chứa zip base64) ----------
// Playwright < 1.51 (VD 1.47) KHÔNG sinh data/*.md — toàn bộ kết quả nằm trong <script id="playwrightReportBase64">.
function readZipEntries(buf) {
  const eocd = buf.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  if (eocd < 0) throw new Error('Không phải file zip');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const files = {};
  for (let i = 0; i < count; i++) {
    const method = buf.readUInt16LE(p + 10);
    const size = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const local = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen);
    const start = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
    const raw = buf.subarray(start, start + size);
    files[name] = method === 0 ? raw : inflateRawSync(raw);
    p += 46 + nameLen + extraLen + commentLen;
  }
  return files;
}

const stripAnsi = (s) => String(s || '').replace(/\x1b\[[0-9;]*m/g, '');

// files: { 'report.json': Buffer, '<fileId>.json': Buffer, ... } -> failures[]
function failuresFromReportFiles(files, reportDir) {
  const report = JSON.parse(files['report.json'].toString('utf8'));
  const failures = [];
  for (const f of report.files) {
    const spec = JSON.parse(files[`${f.fileId}.json`].toString('utf8'));
    for (const t of spec.tests) {
      if (t.outcome !== 'unexpected') continue; // flaky/skipped/expected không phải fail
      const result = t.results[t.results.length - 1] || {};
      const atts = (result.attachments || []).filter((a) => a.path).map((a) => ({ ...a, abs: join(reportDir, a.path) }));
      const pick = (pred) => atts.filter(pred).map((a) => a.abs);
      failures.push({
        id: `F${String(failures.length + 1).padStart(3, '0')}`,
        source: 'report',
        title: [...(t.path || []), t.title].join(' › '),
        // location.file tương đối theo testDir của project — resolve bằng tên file + project khi sửa
        file: f.fileName,
        project: t.projectName,
        location: `${t.location?.file}:${t.location?.line}:${t.location?.column}`,
        retries: t.results.length - 1,
        error: (result.errors || []).map((e) => stripAnsi(e.message)).join('\n---\n'),
        screenshots: pick((a) => a.contentType === 'image/png'),
        videos: pick((a) => a.contentType === 'video/webm'),
        traces: pick((a) => a.name === 'trace' || a.contentType === 'application/zip'),
      });
    }
  }
  return failures;
}

function parseEmbeddedReport(reportDir) {
  const index = join(reportDir, 'index.html');
  if (!existsSync(index)) return null;
  const m = /id="playwrightReportBase64"[^>]*>\s*data:application\/zip;base64,([A-Za-z0-9+/=]+)/.exec(readFileSync(index, 'utf8'));
  if (!m) return null;
  try {
    return failuresFromReportFiles(readZipEntries(Buffer.from(m[1], 'base64')), reportDir);
  } catch (e) {
    log(`Không đọc được report nhúng trong index.html: ${e.message} — thử data/*.md`);
    return null;
  }
}

const parseReport = (reportDir) => parseEmbeddedReport(reportDir) ?? parsePlaywrightReport(reportDir);

// Playwright HTML report mới: data/*.md (hoặc .markdown) có "- Name:", "- Location:", "# Error details"
function parsePlaywrightReport(reportDir) {
  const files = walk(join(reportDir, 'data'), (p) => /\.(md|markdown)$/.test(p));
  const dataDir = join(reportDir, 'data');
  const assets = existsSync(dataDir) ? walk(dataDir) : [];
  return files.map((file, i) => {
    const text = readFileSync(file, 'utf8');
    const name = /^- Name:\s*(.+)$/m.exec(text)?.[1]?.trim() || basename(file);
    const location = /^- Location:\s*(.+)$/m.exec(text)?.[1]?.trim() || '';
    const error = /# Error details\s*```[a-z]*\n([\s\S]*?)```/.exec(text)?.[1]?.trim() || '';
    const stem = basename(file, extname(file));
    const related = assets.filter((a) => basename(a).startsWith(stem) && a !== file);
    return {
      id: `F${String(i + 1).padStart(3, '0')}`,
      source: 'report',
      title: name,
      file: location.split(':')[0].replace(/^.*?(tests?[-\w]*\/)/, '$1'),
      location,
      error,
      screenshots: related.filter((a) => a.endsWith('.png')),
      videos: related.filter((a) => a.endsWith('.webm')),
      traces: related.filter((a) => a.endsWith('.zip')),
      reportMarkdown: file,
    };
  });
}

// ---------- ReportPortal ----------
async function rpGet(path, { binary = false } = {}) {
  const base = process.env.REPORT_PORTAL_ENDPOINT.replace(/\/$/, '');
  const res = await fetch(`${base}${path}`, {
    headers: { Authorization: `Bearer ${process.env.REPORT_PORTAL_API_KEY}` },
  });
  if (!res.ok) throw new Error(`ReportPortal GET ${path} -> ${res.status}`);
  return binary ? Buffer.from(await res.arrayBuffer()) : res.json();
}

const MIME_EXT = { 'image/png': '.png', 'video/webm': '.webm', 'application/zip': '.zip', 'text/plain': '.txt' };

async function fetchReportPortal(rp, out, failures, hasReport) {
  let unmatched = 0;
  const project = rp.project.toLowerCase();
  const evidence = join(out, 'reportportal');
  mkdirSync(evidence, { recursive: true });
  const maxAttach = Number(args['max-attachments'] || 60);
  let attached = 0;
  try {
    const launch = await rpGet(`/api/v1/${project}/launch/${rp.launchId}`);
    const items = [];
    for (let page = 1; page <= 20; page++) {
      const res = await rpGet(
        `/api/v1/${project}/item?filter.eq.launchId=${rp.launchId}&filter.eq.status=FAILED` +
          `&filter.eq.hasChildren=false&page.page=${page}&page.size=100`,
      );
      items.push(...res.content);
      if (page >= (res.page?.totalPages || 1)) break;
    }
    for (const item of items) {
      const logs = (await rpGet(`/api/v1/${project}/log?filter.eq.item=${item.id}&page.size=100`)).content || [];
      const errorLogs = logs.filter((l) => ['ERROR', 'FATAL'].includes(l.level)).map((l) => l.message);
      const files = [];
      for (const l of logs) {
        if (!l.binaryContent?.id || attached >= maxAttach) continue;
        const ext = MIME_EXT[l.binaryContent.contentType] || '';
        const dest = join(evidence, `item${item.id}_${l.binaryContent.id}${ext}`);
        writeFileSync(dest, await rpGet(`/api/v1/${project}/data/${l.binaryContent.id}`, { binary: true }));
        files.push(dest);
        attached++;
      }
      const match = failures.find((f) => f.title && (f.title.includes(item.name) || item.name.includes(f.title)));
      // Đã có report Playwright -> report là nguồn sự thật về danh sách fail; RP chỉ bổ sung log/ảnh/video.
      // Item RP không khớp (thường là lần chạy đầu của test pass ở retry) không được cộng thêm -> tránh đếm trùng.
      if (!match && hasReport) {
        unmatched++;
        continue;
      }
      const pick = (ext) => files.filter((f) => f.endsWith(ext));
      if (match) {
        match.rpItemId = item.id;
        match.rpErrorLog = errorLogs.join('\n').slice(0, 4000);
        match.screenshots.push(...pick('.png'));
        match.videos.push(...pick('.webm'));
        match.traces.push(...pick('.zip'));
      } else {
        failures.push({
          id: `R${item.id}`,
          source: 'reportportal',
          title: item.name,
          file: item.codeRef?.split('/').slice(0, -1).join('/') || '',
          location: item.codeRef || '',
          error: errorLogs.join('\n').slice(0, 4000),
          rpItemId: item.id,
          screenshots: pick('.png'),
          videos: pick('.webm'),
          traces: pick('.zip'),
        });
      }
    }
    log(`ReportPortal launch ${rp.launchId}: ${items.length} item FAILED, ${attached} attachment${unmatched ? `, ${unmatched} item không khớp report (bỏ qua)` : ''}`);
    return { ...rp, launchName: launch.name, failedItems: items.length, unmatchedItems: unmatched, attachments: attached };
  } catch (e) {
    log(`ReportPortal lỗi: ${e.message} — tiếp tục với dữ liệu artifact.`);
    return { ...rp, error: e.message };
  }
}

// ---------- classify ----------
// Thứ tự quan trọng: luật đầu tiên khớp thì thắng. fixability: auto = sửa được trong code test.
const RULES = [
  { cat: 'BROWSER_CLOSED', fix: 'derived', re: /target page, context or browser has been closed/i, hint: 'Triệu chứng phái sinh — tìm lỗi đầu tiên của cùng test' },
  { cat: 'ENV_HTTP_5XX', fix: 'needs-human', re: /(?<![:\w.])50[0-4](?![\w:.])|bad gateway|service unavailable|gateway time-?out/i, hint: 'Server môi trường lỗi — không sửa bằng code test' },
  { cat: 'ENV_NETWORK', fix: 'needs-human', re: /net::ERR_|ECONNREFUSED|ECONNRESET|ENOTFOUND|getaddrinfo|ETIMEDOUT/i, hint: 'Mạng / DNS / môi trường không truy cập được' },
  { cat: 'ENV_DB', fix: 'needs-human', re: /ORA-\d+|ER_[A-Z_]+|NJS-\d+|mysql|oracledb/i, hint: 'Lỗi kết nối hoặc truy vấn DB' },
  { cat: 'DATA_CONFLICT', fix: 'auto', re: /already exists|duplicate|unique constraint|一意制約|既に登録/i, hint: 'Dữ liệu test trùng — sinh data unique' },
  { cat: 'AUTH_STATE', fix: 'needs-human', re: /ログイン|storageState|\.auth\b|login (failed|page)|sign.?in|session (expired|invalid)|(?<![:\w.])40[13](?![\w:.])/i, hint: 'Đăng nhập / phiên hết hạn — kiểm tra tài khoản & cache login trước khi sửa code' },
  { cat: 'ASSERT_TEXT', fix: 'auto', re: /toContainText|toHaveText|toHaveValue|toHaveTitle|toHaveURL/, hint: 'Sai nội dung kỳ vọng — xác minh UI thật rồi mới sửa' },
  { cat: 'ASSERT_VISIBLE', fix: 'auto', re: /toBeVisible|toBeHidden|toBeEnabled|toBeChecked|element\(s\) not found/, hint: 'Phần tử không hiện — locator hoặc timing' },
  { cat: 'LOCATOR_TIMEOUT', fix: 'auto', re: /locator\.(waitFor|click|fill|check|selectOption|press|hover)|waiting for (getBy|locator)|strict mode violation/i, hint: 'Locator / chờ phần tử — locator hỏng hoặc không ổn định' },
  { cat: 'TEST_TIMEOUT', fix: 'auto', re: /test timeout of \d+ms exceeded|page\.waitFor|timeout \d+ms exceeded/i, hint: 'Test quá thời gian — timing hoặc flow quá dài' },
];

function signature(error) {
  const firstLine = (error || '').split('\n').find((l) => l.trim()) || '(không có thông báo lỗi)';
  return firstLine
    .replace(/\x1b\[[0-9;]*m/g, '')
    .replace(/https?:\/\/\S+/g, '<url>')
    .replace(/\b[0-9a-f]{8,}\b/gi, '<hex>')
    .replace(/\d+(\.\d+)?\s?(ms|s)\b/g, '<t>')
    .replace(/\d+/g, '<n>')
    .replace(/(["'`]).{0,80}?\1/g, '<str>')
    .trim()
    .slice(0, 160);
}

function cmdClassify() {
  const inFile = resolve(need('in'));
  const data = JSON.parse(readFileSync(inFile, 'utf8'));
  const byKey = new Map();
  for (const f of data.failures) {
    const rule = RULES.find((r) => r.re.test(`${f.error}\n${f.rpErrorLog || ''}`)) || {
      cat: 'UNKNOWN', fix: 'needs-analysis', hint: 'Chưa khớp luật nào — cần đọc trace/screenshot',
    };
    const sig = signature(f.error);
    const key = `${rule.cat}|${sig}`;
    if (!byKey.has(key)) byKey.set(key, { category: rule.cat, fixability: rule.fix, signature: sig, hint: rule.hint, tests: [] });
    byKey.get(key).tests.push(f);
  }
  const clusters = [...byKey.values()]
    .sort((a, b) => b.tests.length - a.tests.length)
    .map((c, i) => ({
      clusterId: `C${String(i + 1).padStart(2, '0')}`,
      category: c.category,
      fixability: c.fixability,
      signature: c.signature,
      hint: c.hint,
      count: c.tests.length,
      files: [...new Set(c.tests.map((t) => t.file).filter(Boolean))],
      tests: c.tests.map((t) => ({ id: t.id, title: t.title, file: t.file, location: t.location })),
      representative: {
        error: c.tests[0].error.slice(0, 1200),
        screenshot: c.tests.find((t) => t.screenshots?.length)?.screenshots[0] || null,
        video: c.tests.find((t) => t.videos?.length)?.videos[0] || null,
        trace: c.tests.find((t) => t.traces?.length)?.traces[0] || null,
      },
    }));

  // Cụm auto-fix chung spec file -> cùng một batch để 2 fixer không sửa đè nhau
  const fixable = clusters.filter((c) => c.fixability === 'auto' || c.fixability === 'needs-analysis');
  const parent = Object.fromEntries(fixable.map((c) => [c.clusterId, c.clusterId]));
  const find = (x) => (parent[x] === x ? x : (parent[x] = find(parent[x])));
  const owner = new Map();
  for (const c of fixable)
    for (const file of c.files) {
      if (owner.has(file)) parent[find(c.clusterId)] = find(owner.get(file));
      else owner.set(file, c.clusterId);
    }
  const batches = {};
  for (const c of fixable) (batches[find(c.clusterId)] ||= []).push(c.clusterId);
  const batchList = Object.values(batches).map((ids, i) => ({ batchId: `B${i + 1}`, clusterIds: ids }));

  const outFile = join(resolve(inFile, '..'), 'clusters.json');
  writeJson(outFile, {
    runId: data.runId,
    totalFailures: data.total,
    clusters,
    batches: batchList,
    summary: Object.fromEntries(
      ['auto', 'needs-analysis', 'needs-human', 'derived'].map((k) => [k, clusters.filter((c) => c.fixability === k).reduce((n, c) => n + c.count, 0)]),
    ),
  });
  console.log(JSON.stringify({ clusters: clusters.length, batches: batchList.length, file: outFile }));
}

// ---------- PR / comment / dispatch ----------
async function cmdOpenPr() {
  const repo = need('repo');
  const head = need('branch');
  const body = readFileSync(need('body-file'), 'utf8');
  let pr;
  try {
    pr = await gh(`/repos/${repo}/pulls`, {
      method: 'POST',
      body: { title: need('title'), head, base: args.base || 'master', body, draft: false },
    });
  } catch (e) {
    if (e.status !== 422) throw e;
    const owner = repo.split('/')[0];
    const [existing] = await gh(`/repos/${repo}/pulls?head=${owner}:${head}&state=open`);
    if (!existing) throw e;
    pr = await gh(`/repos/${repo}/pulls/${existing.number}`, { method: 'PATCH', body: { body } });
  }
  const labels = [].concat(args.label || ['ai-fix']);
  await gh(`/repos/${repo}/issues/${pr.number}/labels`, { method: 'POST', body: { labels } }).catch((e) => log(`Gắn label lỗi: ${e.message}`));
  console.log(JSON.stringify({ number: pr.number, url: pr.html_url }));
}

async function cmdComment() {
  const repo = need('repo');
  let pr = args.pr;
  if (!pr) {
    const [found] = await gh(`/repos/${repo}/pulls?head=${repo.split('/')[0]}:${need('branch')}&state=open`);
    if (!found) fail(`Không có PR mở cho nhánh ${args.branch}`);
    pr = found.number;
  }
  await gh(`/repos/${repo}/issues/${pr}/comments`, { method: 'POST', body: { body: readFileSync(need('body-file'), 'utf8') } });
  console.log(JSON.stringify({ pr: Number(pr), commented: true }));
}

async function cmdDispatch() {
  const repo = need('repo');
  const inputs = Object.fromEntries([].concat(args.input || []).map((kv) => [kv.slice(0, kv.indexOf('=')), kv.slice(kv.indexOf('=') + 1)]));
  await gh(`/repos/${repo}/actions/workflows/${need('workflow')}/dispatches`, {
    method: 'POST',
    body: { ref: need('ref'), inputs },
  });
  console.log(JSON.stringify({ dispatched: need('workflow'), ref: args.ref, inputs }));
}

// ---------- clone / push (git có token) ----------
// Token đi qua GIT_CONFIG_* env của tiến trình con: không nằm trong argv, không ghi vào .git/config, không in ra.
function gitAuthed(gitArgs, cwd) {
  if (!GH_TOKEN) fail('Thiếu GH_TOKEN / GITHUB_TOKEN');
  const basic = Buffer.from(`x-access-token:${GH_TOKEN}`).toString('base64');
  const r = spawnSync('git', gitArgs, {
    cwd,
    stdio: ['ignore', 'inherit', 'pipe'],
    env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GIT_CONFIG_COUNT: '1', GIT_CONFIG_KEY_0: 'http.extraheader', GIT_CONFIG_VALUE_0: `Authorization: Basic ${basic}` },
  });
  const err = (r.stderr?.toString() || '').replaceAll(GH_TOKEN, '***').replaceAll(basic, '***');
  if (err) process.stderr.write(err);
  if (r.error || r.status !== 0) fail(`git ${gitArgs[0]} thất bại (exit ${r.status})`);
}
const GH_HOST = (process.env.GITHUB_SERVER_URL || 'https://github.com').replace(/\/$/, '');

function cmdClone() {
  const repo = need('repo');
  const dir = resolve(need('dir'));
  if (existsSync(join(dir, '.git'))) {
    gitAuthed(['fetch', '--prune', 'origin'], dir);
  } else {
    mkdirSync(resolve(dir, '..'), { recursive: true });
    gitAuthed(['clone', '--no-single-branch', `${GH_HOST}/${repo}.git`, dir]);
  }
  // symlink/junction node_modules của worktree: `node_modules/` trong .gitignore chỉ khớp thư mục, không khớp symlink
  const exclude = join(dir, '.git', 'info', 'exclude');
  const cur = existsSync(exclude) ? readFileSync(exclude, 'utf8') : '';
  if (!cur.split(/\r?\n/).includes('node_modules')) writeFileSync(exclude, `${cur}${cur && !cur.endsWith('\n') ? '\n' : ''}node_modules\n.auth\n`);
  console.log(JSON.stringify({ cloned: repo, dir }));
}

// Chốt chặn cứng: chỉ nhánh ai-fix/*, không bao giờ force. Agent không được dùng `git push` trực tiếp.
function cmdPush() {
  const dir = resolve(args.dir || '.');
  const branch = need('branch');
  if (!/^ai-fix\/[\w.\-\/]+$/.test(branch)) fail(`Từ chối push "${branch}": chỉ được push nhánh ai-fix/*`);
  if (Object.keys(args).some((k) => k.startsWith('force'))) fail('Từ chối: không bao giờ force push');
  gitAuthed(['push', 'origin', `refs/heads/${branch}:refs/heads/${branch}`], dir);
  console.log(JSON.stringify({ pushed: branch }));
}

const commands = { fetch: cmdFetch, classify: cmdClassify, clone: cmdClone, push: cmdPush, 'open-pr': cmdOpenPr, comment: cmdComment, dispatch: cmdDispatch };
if (!commands[cmd]) fail(`Dùng: ci_autofix.mjs <${Object.keys(commands).join('|')}> [--tham-số ...]`);
Promise.resolve(commands[cmd]()).catch((e) => fail(e.message));
