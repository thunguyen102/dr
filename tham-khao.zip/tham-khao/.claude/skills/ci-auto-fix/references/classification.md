# Phân loại lỗi CI Playwright theo cụm

> Phương pháp gốc: skill `playwright-report-classify` (repo dodax-e2e-test) — phân loại **nhẹ và nhanh**: đếm tổng, gom theo nguyên nhân, mỗi cụm liệt kê vài test đại diện, kết bằng một câu nói rõ nguyên nhân chủ đạo. Bản này thêm tầng **"sửa được bằng code test hay không"** để phục vụ auto-fix.

## 1. Nguồn dữ liệu

Đọc `failures.json` (script `fetch` đã gom sẵn) — không tự parse lại report. Script lấy danh sách fail từ report Playwright (report nhúng trong `index.html` với Playwright < 1.51, hoặc `data/*.md` với bản mới); ReportPortal chỉ **bổ sung** log ERROR + ảnh/video/trace, và là nguồn chính **chỉ khi** không có artifact report (`failures[].source = "reportportal"`).

Không mở trace của mọi test. Chỉ mở **trace đại diện của mỗi cụm** khi cần xác nhận.

## 2. Taxonomy

| Category | Dấu hiệu | `fixability` | Hướng xử lý |
|---|---|---|---|
| `LOCATOR_TIMEOUT` | `locator.click/fill/waitFor … Timeout`, `waiting for getBy…`, `strict mode violation` | `auto` | Inspect DOM thật → locator semantic ổn định; kiểm tra có đổi UI không |
| `ASSERT_VISIBLE` | `toBeVisible/toBeHidden/toBeEnabled … element(s) not found` | `auto` | Xác định: locator sai, timing, hay UI thật sự không hiện (→ có thể là bug sản phẩm) |
| `ASSERT_TEXT` | `toContainText/toHaveText/toHaveValue/toHaveURL` không khớp | `auto` | So nội dung thật vs kỳ vọng. UI đổi chữ có chủ đích → sửa kỳ vọng; UI sai → `needs-human` |
| `TEST_TIMEOUT` | `Test timeout of Nms exceeded` | `auto` | Flow quá dài hoặc đợi sai chỗ; **không** chỉ tăng timeout |
| `DATA_CONFLICT` | `already exists`, `duplicate`, `unique constraint`, `一意制約` | `auto` | Sinh data unique + traceable, cleanup |
| `AUTH_STATE` | `ログイン…`, `storageState`, `.auth`, 401/403, "login page" | `needs-human` → xét lại | Tài khoản khoá / mật khẩu đổi / cache login hết hạn là việc người. Chỉ `auto` khi chứng minh test code gọi sai luồng |
| `ENV_HTTP_5XX` | 500–504, Bad Gateway, Service Unavailable | `needs-human` | Môi trường lỗi — báo DevOps/dev |
| `ENV_NETWORK` | `net::ERR_*`, `ECONNREFUSED`, `ENOTFOUND`, `ETIMEDOUT` | `needs-human` | Mạng/DNS/proxy/runner |
| `ENV_DB` | `ORA-…`, `ER_…`, `NJS-…`, oracledb/mysql | `needs-human` | DB/kết nối/dữ liệu nền |
| `BROWSER_CLOSED` | `Target page, context or browser has been closed` | `derived` | **Phái sinh** — luôn có lỗi đầu tiên trước nó (timeout/assert). Gộp vào cụm của lỗi đầu |
| `UNKNOWN` | không khớp luật nào | `needs-analysis` | Đọc screenshot + trace đại diện rồi xếp lại |

## 3. Quy tắc gom cụm

- Cụm = `category` + **chữ ký lỗi** (dòng lỗi đầu, đã bỏ số, URL, chuỗi trong nháy, thời gian)
- **Lỗi đầu tiên thắng**: test có lỗi chính + lỗi phái sinh → tính vào lỗi chính, không đếm hai lần
- Hai cụm cùng một nguyên nhân gốc (cùng page object / cùng bước login dùng chung) → **gộp**, dù chữ ký hơi khác
- Cụm `auto` chung spec file → cùng một **batch** (để hai `ci-fixer` không sửa đè)
- Tổng `count` mọi cụm **phải bằng** tổng test fail

## 4. Sai số đã biết của phân loại cơ học

| Tình huống | Xử lý |
|---|---|
| Regex bắt nhầm mã `5xx` trong số dòng/ID | Script đã chặn số đi kèm `:`/chữ/chấm; vẫn phải soát mắt cụm `ENV_HTTP_5XX` |
| `locator.waitFor timeout` do **trang lỗi** (5xx hiển thị trên UI) chứ không phải locator hỏng | Xem screenshot/page snapshot của test đại diện trước khi chốt `auto` |
| Lỗi login lan ra hàng loạt test | Tìm test đầu tiên fail ở bước login — thường 1 nguyên nhân cho cả cụm lớn |
| Tên test tiếng Nhật / có ký tự đặc biệt | Khớp RP ↔ report theo `includes`; không khớp thì giữ riêng, đừng ép gộp |

## 5. Định dạng tóm tắt khi báo cáo nhanh

```text
Tổng <N> test fail → <K> cụm.
1. <Category> (<n>/<N>) — <auto | cần người>
   - nguyên nhân: <chữ ký lỗi>
   - đại diện: <spec> (<test>) · <spec> (<test>)   (chỉ 2–3 ví dụ)
Nguyên nhân chủ đạo: <category> (<n>/<N>).
```
