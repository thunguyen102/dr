# Project profile — CI Auto-Fix

> Điền cho từng project, lưu thành `project_profile.md` cùng thư mục. `ci-auto-fix` và `ci-fixer` đọc file này **trước** và để nó ghi đè mặc định.

## 1. Chạy một spec ở local (cổng "pass local")

- Lệnh: `<npx playwright test --project=<project> <spec> --retries=0>`
- Cách chọn project theo đường dẫn spec: <quy tắc>
- Chuẩn bị bắt buộc trước khi chạy: <npm ci · tải login cache · biến môi trường · client DB…>
- Số lần chạy lại để coi là pass: <n>; ngoại lệ (test đổi dữ liệu thật): <1 lần>

## 2. Quality gate trước khi commit

<lệnh typecheck / lint / format — phải pass; hook pre-commit nếu có>

## 3. Phạm vi sửa

- Được sửa: <thư mục>
- Cấm sửa (cần người): <config, workflow, dữ liệu test, env, lockfile…>

## 4. Chạy lại CI

- Workflow: <file> · input: <tên input môi trường> · <tên input danh sách spec>
- Cách suy ra môi trường của run lỗi: <…>

## 5. Đặc thù / bẫy riêng của project

<…>
