# Mẫu báo cáo AI — `ai_fix_report.md`

Người đọc: tester duyệt PR, lead, DevOps. Họ cần biết trong **1 phút**: AI sửa được gì, **mình phải làm gì**. Chi tiết kỹ thuật để phía dưới.

Quy tắc viết:
- Mỗi thông tin xuất hiện **đúng một chỗ**. Số lượng + trạng thái chỉ nằm ở bảng *Tổng quan*; phần chi tiết không lặp lại.
- Đơn vị đếm luôn là **test** (không trộn test với cụm).
- Tên cụm = **mô tả lỗi bằng lời thường** (`Nút 検索 đổi nhãn → locator cũ không tìm thấy`), mã category để trong ngoặc ở phần chi tiết.
- Chỉ 3 trạng thái: ✅ **AI đã sửa** (pass local) · ❌ **AI chưa sửa được** (đã huỷ thay đổi, không push) · 👤 **Cần người xử lý**.
- Số liệu lấy từ `run.json` · `clusters.json` · `fixes/*/result.json`. Thiếu dữ liệu → ghi `không có dữ liệu`, không bịa.
- Phần từ đầu tới hết *Tổng quan* (đánh dấu `<!-- pr-body:end -->`) chính là nội dung PR — `pr_body.md` = phần đó + link tới báo cáo đầy đủ. Không viết riêng một bản tóm tắt khác.

````markdown
# Run #<runId>: AI đã sửa <a>/<N> test fail · <c> test cần người xử lý

> 🤖 Báo cáo do AI tạo. PR: <link PR hoặc "không có — không có gì được push"> · CI chạy lại: <⏳ đang chạy (link run) | không trigger vì …>. Kết quả CI chạy lại sẽ được comment vào PR.

## Việc cần làm

| Ai | Việc | Cụm |
|---|---|---|
| Tester | Review PR (<số> file đổi), xem video các test đã sửa, merge khi đồng ý | C01, C03 |
| <DevOps / dev sản phẩm / chủ tài khoản test> | <việc cụ thể, VD: server staging trả 503 lúc 02:10 — kiểm tra service X> | C02 |

<Thêm dòng "Tester — chạy full suite trước khi merge" nếu có sửa file dùng chung (base-page, login helper…).>

## Tổng quan

| Cụm | Lỗi gì | Số test | Kết quả |
|---|---|---|---|
| C01 | <Nút 検索 đổi nhãn → locator cũ không tìm thấy> | <12> | ✅ AI đã sửa · pass local <2/2> |
| C02 | <Server staging trả 503> | <7> | 👤 DevOps |
| C03 | <…> | <6> | ❌ AI chưa sửa được — <lý do ngắn> |
| | **Tổng** | **<N>** | ✅ <a> · ❌ <b> · 👤 <c> |

<!-- pr-body:end -->

## Chi tiết từng cụm

### C01 — <mô tả lỗi> (`<CATEGORY>`)

- **Nguyên nhân:** <giải thích dựa trên bằng chứng>
- **Cách khắc phục:** <đã đổi gì, vì sao an toàn> — `<file>` (<+x −y>)
- **Bằng chứng:** `<1 dòng lỗi đại diện>` · [ảnh](<đường dẫn>) · [trace](<đường dẫn>)
- **Cần để ý khi review:** <giả định chưa kiểm chứng, tác dụng phụ — bỏ dòng nếu không có>

<details><summary>Test bị ảnh hưởng (<n>)</summary>

- <spec> — <tên test>

</details>

### C02 — <mô tả lỗi> (`<CATEGORY>`) — cần người

- **Nguyên nhân:** <…>
- **Vì sao AI không sửa:** <lỗi môi trường / tài khoản / nghi bug sản phẩm — sửa test sẽ che lỗi>
- **Bằng chứng:** <…>

<details><summary>Test bị ảnh hưởng (<n>)</summary>…</details>

### C03 — <mô tả lỗi> (`<CATEGORY>`) — AI chưa sửa được

- **Nguyên nhân (nghi ngờ):** <…>
- **Đã thử:** <cách đã thử> → <kết quả chạy local, VD 0/2 pass>. Thay đổi đã huỷ, không có gì được push.
- **Gợi ý cho người xử lý:** <bước tiếp theo nên thử>

## Giới hạn

<Bỏ cả mục nếu không có. Chỉ ghi: batch bị loại do xung đột · mâu thuẫn số liệu giữa các file · phần chưa kiểm chứng được.>

## Thông tin run

| | |
|---|---|
| Run lỗi | [<workflow> #<runId>](<url>) · nhánh `<headBranch>` · commit `<sha7>` |
| ReportPortal | <link hoặc "không có"> |
| Nhánh fix | `<ai-fix/…>` · lần sửa <attempt>/<maxAttempts> |
| Dữ liệu & nhật ký | `failures.json` · `clusters.json` · `fixes/*/result.json` · `logs/orchestrator.md` · bằng chứng: `report/` `reportportal/` `ci-logs/` |
````
