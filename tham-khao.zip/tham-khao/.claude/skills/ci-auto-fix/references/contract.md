# CI Auto-Fix — Hợp đồng dữ liệu & guardrail chung

> Dùng chung bởi agent chính [`/ci-auto-fix`](../SKILL.md) và 4 subagent trong `.claude/agents/`: `ci-failure-fetcher` · `ci-failure-classifier` · `ci-fixer` · `ci-fix-reporter`.

## 1. Nguyên tắc gốc

| # | Nguyên tắc | Vì sao |
|---|---|---|
| 1 | **Phân loại theo cụm, sửa theo cụm** — không sửa từng test một | Một lần CI fail hàng chục test thường chỉ có vài nguyên nhân gốc (cùng locator, cùng bước login). Sửa từng test là tốn công và dễ sửa mỗi nơi một kiểu |
| 2 | **Không phải lỗi nào cũng sửa bằng code test** | Lỗi môi trường (5xx, DB, mạng), tài khoản test hỏng, bug sản phẩm — sửa test để "xanh" là **che bug**. Cụm loại này → `needs-human`, có báo cáo, không có commit |
| 3 | **Xanh phải là xanh thật** — cấm `waitForTimeout`, xoá/làm yếu assertion, `skip`, nuốt lỗi | Test xanh giả tệ hơn test đỏ |
| 4 | **Người là chốt chặn cuối** — AI chỉ push nhánh `ai-fix/*` + mở PR; tester duyệt và merge | Gắn với B4. AI không có đường nào tới nhánh gốc |
| 5 | **Đo bằng chứng, không đoán** — mọi kết luận nguyên nhân trỏ được tới screenshot / trace / log / dòng lỗi | Người duyệt kiểm lại được; kết luận không có bằng chứng = đoán |
| 6 | **Sửa → pass local → mới push → mới chạy CI.** `fixed` chỉ khi mọi test của batch đã chạy lại pass ở local; không chạy được hoặc không pass thì **huỷ thay đổi, không push** | CI chậm và tốn tài nguyên chung — không dùng nó để thử sai. Không có trạng thái "fix chưa verify" |

## 2. Hợp đồng dữ liệu

Thư mục làm việc: `claude-report/ci-autofix/run_<runId>/` (gitignored — `install.mjs` tự thêm `claude-report/` và `.ci-autofix-work/` vào `.gitignore`). **Không** dùng `reports/`: ở project doda đó là source code (Teams reporter).

| File | Do ai tạo | Trường chính |
|---|---|---|
| `run.json` | script `fetch` | `runId`, `headBranch`, `headSha`, `conclusion`, `path` (file workflow), `url` |
| `failures.json` | script `fetch` | `failures[]`: `id`, `title`, `file`, `error`, `screenshots[]`, `videos[]`, `traces[]`, `rpItemId?` |
| `clusters.json` | script `classify` + `ci-failure-classifier` soát | `clusters[]`: `clusterId`, `category`, `fixability`, `count`, `files[]`, `tests[]`, `representative`; `batches[]` |
| `fixes/<batchId>/result.json` | `ci-fixer` | `status`, `branch`, `commit`, `filesChanged[]`, `tests[]{rootCause,fix,verified}`, `verify{ran,passed,total}` |
| `integration.json` · `dispatch.json` · `pr.json` | agent chính | kết quả hợp nhất · trigger CI · PR |
| `ai_fix_report.md` · `pr_body.md` | `ci-fix-reporter` | xem [`report_template.md`](report_template.md) |

`status` của batch: `fixed` · `not-fixed` · `needs-human`.

**Profile dự án** — `project_profile.md` (cùng thư mục, nếu có) ghi đè mặc định: lệnh chạy spec, project Playwright, quality gate, thư mục được sửa, workflow/input để chạy lại CI. Thư mục làm việc **không** đổi được qua profile (workflow upload cố định `claude-report/ci-autofix/`). Tạo bằng `install.mjs --profile <tên>` từ `profiles/<tên>.md` (hiện có `doda-e2e`, `agentic-e2e-v2`); project mới → điền [`project_profile.template.md`](project_profile.template.md).

`fixability`: `auto` (sửa bằng code test) · `needs-analysis` (chưa rõ, `ci-fixer` phân tích trước rồi quyết) · `needs-human` (không sửa) · `derived` (triệu chứng phái sinh, gộp vào cụm gốc).

## 3. Phân loại lỗi

Taxonomy đầy đủ + cách nhận biết + hướng xử lý: [`classification.md`](classification.md).

## 4. Guardrail — ba lớp, mỗi lớp một nguồn

| Lớp | Nguồn duy nhất | Chặn gì |
|---|---|---|
| Hướng dẫn cho AI | mục *Guardrail* trong [`ci-fixer.md`](../../../agents/ci-fixer.md) (+ mục 3 của `project_profile.md` cho phạm vi thư mục) | Được sửa gì / cấm gì khi sửa code |
| Kiểm tra sau khi gộp | *Checklist đầu ra cuối* trong [`SKILL.md`](../SKILL.md) | Diff chạm thư mục cấm, `waitForTimeout`/`skip`/nuốt lỗi, số test bị rơi |
| Chặn cứng | `ci_autofix.mjs push` (chỉ `ai-fix/*`, không force) + `--disallowedTools` trong `ai-autofix.yml` (`git push/merge/rebase/reset --hard/add -A`…) | Dù AI làm sai hướng dẫn, vẫn không đụng được nhánh gốc |

Sửa danh sách ở **nguồn của lớp đó**, không chép sang file khác.

## 5. Phối hợp với skill khác

| Cần | Dùng |
|---|---|
| Quy trình phân tích + sửa + verify một test flaky | workflow `analyze-flaky-tests` (Mode FIX) — `ci-fixer` chạy theo, bỏ checkpoint chờ user |
| Locator hỏng sau khi UI đổi | `skills-locator-agent` (Mode HEAL) |
| Review chất lượng code sau khi sửa | Tester review diff trong PR (tuỳ chọn: `/code-review`) trước khi merge |

## 6. Cài đặt & kích hoạt trên CI

Workflow bắt event `workflow_run`, secrets cần có, cách cài vào project thật: [`scripts/ci-autofix/README.md`](../../../../scripts/ci-autofix/README.md).
