---
name: ci-auto-fix
description: Agent chính điều phối AI tự fix lỗi test automation trên CI (GitHub Actions + ReportPortal) — tải bằng chứng fail, phân loại theo cụm nguyên nhân, nhiều ci-fixer chạy song song sửa từng batch trong worktree riêng, push nhánh ai-fix, trigger CI chạy lại, mở PR cho tester duyệt và xuất báo cáo tiếng Việt. KHÔNG tự merge. 2 modes — FIX (CI fail) và FINALIZE (CI chạy lại trên nhánh ai-fix đã xanh).
---

> **Đọc trước:** [`references/contract.md`](references/contract.md) — hợp đồng dữ liệu, nguyên tắc, guardrail dùng chung với 4 subagent. Nếu có `references/project_profile.md` (do `install.mjs --profile <tên>` tạo khi cài vào project thật; repo demo không có) → đọc luôn: đó là cấu hình riêng của project (lệnh chạy spec, quality gate, thư mục được sửa, workflow/input chạy lại CI) và **ưu tiên hơn** mọi mặc định trong file này.

# Workflow: AI Tự Fix Lỗi Trên CI

> **Vai trò của bạn = điều phối + kiểm tra đầu ra cuối.** Bạn **không** đọc log thô, **không** tự sửa code test, **không** tự phân tích stack trace. Việc đó thuộc subagent. Bạn chỉ đọc `result.json` / `clusters.json` / báo cáo mà chúng trả về, rồi kiểm tra chúng có đạt **Checklist đầu ra cuối** (cuối file) hay không.

## Kiến trúc

```
agent chính (skill này) ── chỉ điều phối + kiểm đầu ra
 ├─ ci-failure-fetcher     (1)   B1  tải log · screenshot · video · report về máy
 ├─ ci-failure-classifier  (1)   B2a phân loại theo cụm nguyên nhân, chia batch độc lập
 ├─ ci-fixer               (N)   B2b chạy SONG SONG — mỗi batch 1 con, 1 worktree riêng
 │    └─ quy trình = /analyze-flaky-tests Mode FIX (chế độ CI)
 └─ ci-fix-reporter        (1)   B5  báo cáo nguyên nhân + cách khắc phục
B3 (push · trigger CI) và PR do agent chính chạy bằng script — là thao tác xác định, không cần LLM phán đoán.
B4 (tester confirm + merge) là việc của NGƯỜI — agent không làm.
```

> ⚠️ Subagent của Claude Code **không spawn được subagent con**. Vì vậy "nhiều con chạy song song" được làm phẳng: **chính agent này spawn N `ci-fixer` trong CÙNG MỘT tin nhắn** (nhiều lời gọi Agent trong một lượt) để chúng chạy song song.

## Input

| Tham số | Bắt buộc | Mặc định | Ý nghĩa |
|---|---|---|---|
| `repo` | ✅ | — | `owner/name` |
| `runId` | ✅ | — | ID run GitHub Actions vừa kết thúc |
| `mode` | | `FIX` | `FIX` khi run **fail** · `FINALIZE` khi run chạy lại trên nhánh `ai-fix/*` đã **xanh** |
| `maxParallel` | | `3` | Số `ci-fixer` chạy cùng lúc (thừa batch → chia đợt). Mỗi fixer mở một Chromium thật đánh vào **cùng môi trường test** — giữ thấp trên runner yếu; lần chạy thật đầu tiên nên dùng `2` |
| `maxAttempts` | | `2` | Số lần AI được sửa cho một nhánh `ai-fix/*` |
| `baseBranch` | | nhánh mặc định của repo | Nhánh PR trỏ vào |
| `workflow` | | file workflow của run (`run.json → path`) | Workflow dùng để trigger chạy lại |
| `env` | | giữ nguyên môi trường của run lỗi | VD `st`, `staging` — truyền vào input `environment` của workflow |

Credentials lấy từ biến môi trường (`GH_TOKEN`, `REPORT_PORTAL_ENDPOINT`, `REPORT_PORTAL_API_KEY`, `ANTHROPIC_API_KEY`) — **không** in ra, không ghi vào file nào.

## Quy tắc an toàn (BẮT BUỘC)

- ❌ **Không bao giờ** merge, force push, push lên nhánh gốc / nhánh mặc định. **Chỉ push qua `ci_autofix.mjs push`** (script chặn cứng nhánh ngoài `ai-fix/*` và force); workflow CI cũng cấm lệnh `git push` trực tiếp.
- ❌ Không làm việc trong thư mục project đang mở của người dùng — fix chạy trong **clone riêng** `.ci-autofix-work/<runId>/repo` (đã `.gitignore`).
- ❌ Chống vòng lặp: nếu run fail đang ở nhánh `ai-fix/*` và đã đủ `maxAttempts` → **dừng**, comment vào PR, chờ người.
- ✅ Mọi quyết định "bỏ qua cụm này" phải được ghi vào báo cáo kèm lý do.

## Mode FIX — các bước

Ghi mỗi bước một dòng vào `<workDir>/logs/orchestrator.md` (giờ · bước · kết quả) — đó là nhật ký cho B5. `workDir = claude-report/ci-autofix/run_<runId>`.

### B1 — Lấy bằng chứng

Spawn **`ci-failure-fetcher`** với `repo`, `runId`, `workDir`. Nhận lại `failuresFile`, `totalFailures`, cảnh báo.
- `totalFailures = 0` → run fail nhưng không có test fail (lỗi setup/infra) → **dừng**, ghi báo cáo "không có test để sửa" kèm đường dẫn log CI, đề nghị người kiểm tra workflow.

### B2a — Phân loại

Spawn **`ci-failure-classifier`** với `failuresFile`. Nhận lại số cụm, danh sách `batches`, cụm `needs-human`.
- Không có cụm `auto` / `needs-analysis` nào → bỏ qua B2b–B3, nhảy tới **B5** (báo cáo chỉ gồm các cụm cần người xử lý).

### B2b — Fix song song

1. Chuẩn bị clone (một lần):
   ```bash
   node scripts/ci-autofix/ci_autofix.mjs clone --repo <repo> --dir .ci-autofix-work/<runId>/repo
   ```
   Script giữ token ngoài argv và `.git/config`, đồng thời thêm `node_modules` + `.auth` vào `.git/info/exclude` (dùng chung cho mọi worktree) để symlink `node_modules` không bị commit nhầm. **Không** tự `git clone` với token.
   - `headBranch` của run đã bắt đầu bằng `ai-fix/` → `FIX_BRANCH = headBranch` (checkout nó). Ngược lại → `git checkout -b ai-fix/run-<runId> <headSha>`.
   - `attempt` = số commit trên `FIX_BRANCH` có trailer `AI-Fix-Attempt:` (đếm bằng `git log --grep`) + 1. `attempt > maxAttempts` → dừng theo quy tắc an toàn.
   - `npm ci` một lần.
2. Mỗi batch một worktree (không ai dẫm chân ai):
   ```bash
   git worktree add ../wt/<batchId> -b <FIX_BRANCH>-<batchId> <FIX_BRANCH>
   # dùng chung node_modules: symlink (Linux/macOS) hoặc junction (Windows) ../wt/<batchId>/node_modules -> repo/node_modules
   ```
3. **Spawn `ci-fixer` song song:** trong **một** tin nhắn, gọi Agent N lần (một lần mỗi batch, tối đa `maxParallel`). Truyền: `batchId`, `clusterIds`, `clustersFile`, `worktree`, `branch`, `workDir`, `attempt`. Batch thừa → đợt kế tiếp sau khi đợt trước xong.
4. Đợi tất cả xong. Đọc `<workDir>/fixes/<batchId>/result.json` của từng batch — **không** đọc lại cả quá trình họ làm.

### Hợp nhất & kiểm tra (đầu ra cuối của B2)

Trong clone, trên `FIX_BRANCH`:
1. Với từng batch `fixed` có `commit`: `git cherry-pick <commit>`. (Batch `not-fixed` / `needs-human` không có commit → không vào.)
   - Xung đột → `git cherry-pick --abort`, đánh dấu batch `conflict`, **chạy lại đúng batch đó một lần** (spawn lại `ci-fixer`, base là `FIX_BRANCH` hiện tại). Vẫn xung đột → loại khỏi lượt này, ghi vào báo cáo.
2. **Cổng local tổng hợp (BẮT BUỘC):** các batch chạy độc lập trong worktree riêng, nên sau khi gộp phải chạy lại **toàn bộ spec đã sửa cùng nhau** trên `FIX_BRANCH` bằng lệnh của `project_profile.md` — phải pass. Đây là "pass local" của cả nhánh; chưa pass thì **không push, không trigger CI**. Fail → xác định batch gây xung đột logic, loại batch đó ra (`git revert`) rồi chạy lại cổng; vẫn fail → dừng, báo cáo `needs-human`.
3. Chạy **Checklist đầu ra cuối** bên dưới. Mục nào hỏng → quay lại batch liên quan (spawn lại 1 lần), không tự sửa code.
4. Ghi `<workDir>/integration.json`: batch nào vào, batch nào loại, kết quả cổng local tổng hợp và từng mục checklist.

### B3 — Push & trigger CI chạy lại

**Thứ tự không đảo được: sửa → pass local → mới push → mới chạy CI.** Chỉ khi cổng local tổng hợp **pass**, checklist **đạt** và có ít nhất 1 commit:
```bash
node scripts/ci-autofix/ci_autofix.mjs push --dir .ci-autofix-work/<runId>/repo --branch <FIX_BRANCH>   # script từ chối nhánh ngoài ai-fix/* và mọi kiểu force
node scripts/ci-autofix/ci_autofix.mjs dispatch --repo <repo> --workflow <workflow> --ref <FIX_BRANCH> \
  --input environment=<env> --input "testFile=<các spec đã sửa, cách nhau bằng dấu cách>"
```
- Push bằng `GITHUB_TOKEN` **không** tự kích hoạt workflow → bắt buộc phải `dispatch` (script dùng `workflow_dispatch`, loại sự kiện được phép).
- Workflow, tên input, cách suy ra môi trường và việc có phải tách nhiều lần dispatch hay không: **theo `project_profile.md` mục *Chạy lại CI*** (nếu có). Không có profile: dùng `run.json` / file workflow; sai tên input → GitHub trả 422, sửa rồi gọi lại.
- Mặc định chỉ chạy lại **các spec đã sửa**. Chạy lại toàn bộ suite là việc tester quyết định trước khi merge.
- Ghi `<workDir>/dispatch.json`.
- Run chạy lại xong sẽ tự kích hoạt `ai-autofix.yml`: **fail** → vào lại Mode FIX (attempt + 1) · **xanh** → Mode FINALIZE.

### B5 — Báo cáo (và mở PR cho B4)

1. Spawn **`ci-fix-reporter`** với `workDir` → `ai_fix_report.md` + `pr_body.md`.
2. Mở PR (nếu đã push):
   ```bash
   node scripts/ci-autofix/ci_autofix.mjs open-pr --repo <repo> --branch <FIX_BRANCH> --base <baseBranch> \
     --title "[AI-Fix] Run #<runId>: sửa <a>/<N> test fail" --body-file <workDir>/pr_body.md --label ai-fix --label needs-tester-review
   ```
   Ghi `pr.json`. PR đã tồn tại thì script cập nhật nội dung.
3. Nhờ workflow upload `claude-report/ci-autofix/run_<runId>/` làm artifact (xem `scripts/ci-autofix/README.md`).

### B4 — Tester confirm & merge: **NGƯỜI làm**

Agent dừng ở đây. Bàn giao: link PR + `ai_fix_report.md`. Gợi ý bật branch protection yêu cầu review trên nhánh gốc để AI không thể vượt qua bước này.

## Mode FINALIZE

Run chạy lại trên nhánh `ai-fix/*` **xanh**:
1. Tìm PR của nhánh → `comment` ngắn: CI xanh ở run #`<runId>`, link run, danh sách spec đã chạy, nhắc tester còn việc confirm/merge, và nhắc chưa chạy full suite (nếu đúng).
2. Không sửa code, không push. Kết thúc.

## Checklist đầu ra cuối — việc duy nhất bạn tự kiểm

Chạy trong clone trên `FIX_BRANCH` sau khi hợp nhất. **Mọi mục phải đạt** trước khi push:

- [ ] Mỗi batch có `result.json` hợp lệ; batch `fixed` có `verify.ran=true` và `passed == total`
- [ ] **Cổng local tổng hợp pass** (mọi spec đã sửa chạy cùng nhau trên `FIX_BRANCH`)
- [ ] `git diff <headSha>..HEAD --stat` chỉ chạm thư mục được phép (mặc định `tests/`, `pages/`, `helpers/`, `fixtures/`; **`project_profile.md` ghi đè danh sách này**) — **không** có `.github/`, `playwright.config.*`, `.env*`, `package*.json`
- [ ] Diff không thêm `waitForTimeout`, `.skip(`, `.fixme(`, `catch {}` rỗng; không xoá assertion
  ```bash
  git diff <headSha>..HEAD | grep -nE '^\+.*(waitForTimeout|\.skip\(|\.fixme\(|catch\s*(\(\w*\))?\s*\{\s*\})' 
  ```
  (có kết quả = **không đạt**)
- [ ] Quality gate của project pass (theo `project_profile.md`; mặc định `npx tsc --noEmit`)
- [ ] Tổng `count` các cụm trong `clusters.json` == `totalFailures` — không test nào bị rơi khỏi báo cáo
- [ ] `ai_fix_report.md` tồn tại, mỗi cụm có đủ: nguyên nhân · cách khắc phục · trạng thái; cụm `needs-human` có lý do

## Output

Toàn bộ file nằm trong `claude-report/ci-autofix/run_<runId>/` — danh sách và schema: [`references/contract.md` mục 2](references/contract.md). Thêm: `report/` · `ci-logs/` · `reportportal/` (bằng chứng đã tải), `logs/orchestrator.md` (nhật ký điều phối). **Báo cáo chính (B5): `ai_fix_report.md`.**

Kết thúc: trả lời người dùng bằng tiếng Việt — số fail · số cụm · đã fix / cần người · link PR · đường dẫn `ai_fix_report.md`.
