---
name: skills-ci-autofix
description: Skill nền tảng cho quy trình AI tự fix lỗi test automation trên CI — hợp đồng dữ liệu giữa các subagent (failures/clusters/result.json), taxonomy phân loại lỗi Playwright theo cụm, guardrail "được sửa gì / cấm gì", mẫu báo cáo AI. Dùng cùng workflow /ci-auto-fix.
---

# Skill Nền Tảng: CI Auto-Fix

> Dùng bởi workflow [`/ci-auto-fix`](../ci-auto-fix/SKILL.md) và 4 subagent trong `.claude/agents/`: `ci-failure-fetcher` · `ci-failure-classifier` · `ci-fixer` · `ci-fix-reporter`.

## 1. Nguyên tắc gốc

| # | Nguyên tắc | Vì sao |
|---|---|---|
| 1 | **Phân loại theo cụm, sửa theo cụm** — không sửa từng test một | Một lần CI fail hàng chục test thường chỉ có vài nguyên nhân gốc (cùng locator, cùng bước login). Sửa từng test là tốn công và dễ sửa mỗi nơi một kiểu |
| 2 | **Không phải lỗi nào cũng sửa bằng code test** | Lỗi môi trường (5xx, DB, mạng), tài khoản test hỏng, bug sản phẩm — sửa test để "xanh" là **che bug**. Cụm loại này → `needs-human`, có báo cáo, không có commit |
| 3 | **Xanh phải là xanh thật** — cấm `waitForTimeout`, xoá/làm yếu assertion, `skip`, nuốt lỗi | Khớp `automation_rules.md`. Test xanh giả tệ hơn test đỏ |
| 4 | **Người là chốt chặn cuối** — AI chỉ push nhánh `ai-fix/*` + mở PR; tester duyệt và merge | Gắn với B4. AI không có đường nào tới nhánh gốc |
| 5 | **Đo bằng chứng, không đoán** — mọi kết luận nguyên nhân trỏ được tới screenshot / trace / log / dòng lỗi | Khớp nguyên tắc Recon của `CLAUDE.md` |
| 6 | **Sửa → pass local → mới push → mới chạy CI.** `fixed` chỉ khi mọi test của batch đã chạy lại pass ở local; không chạy được hoặc không pass thì **huỷ thay đổi, không push** | CI chậm và tốn tài nguyên chung — không dùng nó để thử sai. Không có trạng thái "fix chưa verify" |

## 2. Hợp đồng dữ liệu

Thư mục làm việc: `claude-report/ci-autofix/run_<runId>/` (đã nằm trong `reports/` — gitignored, đúng `reporting_rules.md`).

| File | Do ai tạo | Trường chính |
|---|---|---|
| `run.json` | script `fetch` | `runId`, `headBranch`, `headSha`, `conclusion`, `path` (file workflow), `url` |
| `failures.json` | script `fetch` | `failures[]`: `id`, `title`, `file`, `error`, `screenshots[]`, `videos[]`, `traces[]`, `rpItemId?` |
| `clusters.json` | script `classify` + `ci-failure-classifier` soát | `clusters[]`: `clusterId`, `category`, `fixability`, `count`, `files[]`, `tests[]`, `representative`; `batches[]` |
| `fixes/<batchId>/result.json` | `ci-fixer` | `status`, `branch`, `commit`, `filesChanged[]`, `tests[]{rootCause,fix,verified}`, `verify{ran,passed,total}` |
| `integration.json` · `dispatch.json` · `pr.json` | agent chính | kết quả hợp nhất · trigger CI · PR |
| `ai_fix_report.md` · `pr_body.md` | `ci-fix-reporter` | xem [`references/report_template.md`](references/report_template.md) |

`status` của batch: `fixed` · `not-fixed` · `needs-human` (không còn `partial`).

**Profile dự án** — `references/project_profile.md` (nếu có) ghi đè mặc định: lệnh chạy spec, project Playwright, quality gate, thư mục được sửa, workflow/input để chạy lại CI, thư mục báo cáo. Mẫu: [`references/project_profile.template.md`](references/project_profile.template.md).

`fixability`: `auto` (sửa bằng code test) · `needs-analysis` (chưa rõ, `ci-fixer` phân tích trước rồi quyết) · `needs-human` (không sửa) · `derived` (triệu chứng phái sinh, gộp vào cụm gốc).

## 3. Phân loại lỗi

Taxonomy đầy đủ + cách nhận biết + hướng xử lý: [`references/classification.md`](references/classification.md).

## 4. Guardrail cho `ci-fixer`

**Được sửa** — spec, page object, helper, fixture, test data trong phạm vi batch.
**Cấm** — `.github/`, `playwright.config.*`, `.env*`, `package*.json`; thêm `waitForTimeout`; xoá/yếu assertion; `skip`/`fixme`; nuốt lỗi bằng `try/catch`; `push`/`merge`/`reset --hard`/đổi nhánh; sửa ngoài phạm vi batch.

## 5. Phối hợp với skill khác

| Cần | Dùng |
|---|---|
| Quy trình phân tích + sửa + verify một test flaky | workflow `analyze-flaky-tests` (Mode FIX) — `ci-fixer` chạy theo, bỏ checkpoint chờ user |
| Locator hỏng sau khi UI đổi | `skills-locator-healer-agent` |
| Review chất lượng code sau khi sửa | `/review-automation-code` (tuỳ chọn, tester chạy trước khi merge) |

## 6. Cài đặt & kích hoạt trên CI

Workflow bắt event `workflow_run`, secrets cần có, cách cài vào project thật: [`scripts/ci-autofix/README.md`](../../../scripts/ci-autofix/README.md).
