# Mẫu báo cáo AI — `ai_fix_report.md`

Viết bằng tiếng Việt. Thay `<…>` bằng giá trị thật từ `run.json` · `clusters.json` · `fixes/*/result.json`. Không có dữ liệu thì ghi `không có dữ liệu` — không bịa.

````markdown
# Báo cáo AI tự fix CI — Run #<runId>

## 1. Tóm tắt

| Mục | Giá trị |
|---|---|
| Workflow / nhánh / commit lỗi | <name> · `<headBranch>` · `<headSha 7 ký tự>` |
| Link run lỗi · link ReportPortal | <url> · <url hoặc "không có"> |
| Tổng test fail | <N> |
| Số cụm nguyên nhân | <K> |
| ✅ Đã fix & pass local · 🔧 Đã thử nhưng không pass local (đã huỷ, không push) · 🚫 Cần người xử lý | <a> · <b> · <c> (test) |
| Nhánh fix · PR | `<ai-fix/…>` · <link PR> |
| Lần sửa | <attempt>/<maxAttempts> |
| Trigger CI chạy lại | <đã trigger lúc HH:mm DD-MM-YYYY, workflow, spec> / chưa |

**Nguyên nhân chủ đạo:** <category> (<n>/<N> test) — <1 câu>.

## 2. Phân loại theo cụm

| Cụm | Loại lỗi | Số test | Hướng xử lý | Trạng thái |
|---|---|---|---|---|
| C01 | <category> | <n> | AI sửa / Người xử lý | ✅ / 🔧 / 🚫 |

## 3. Chi tiết từng cụm

### C01 — <category> (<n> test)

- **Nguyên nhân chính:** <giải thích từ bằng chứng, không đoán>
- **Bằng chứng:** lỗi đại diện `<1 dòng>` · ảnh `<đường dẫn tương đối>` · trace `<đường dẫn>`
- **Cách khắc phục:** <đã đổi gì và vì sao>
- **File đã đổi:** `<path>` (<+x −y>)
- **Test bị ảnh hưởng:** <spec> (<tên test>) · … (liệt kê đủ hoặc "xem clusters.json")
- **Verify:** <chạy `<lệnh>` → <passed>/<total> pass> (bắt buộc có cho cụm ✅; cụm 🔧 ghi lý do không pass local và rằng đã huỷ thay đổi)
- **Lưu ý cho người duyệt:** <giả định chưa kiểm chứng, rủi ro tác dụng phụ>

### C02 — … (cụm cần người xử lý)

- **Nguyên nhân chính:** <…>
- **Vì sao AI không sửa:** <môi trường / tài khoản test / nghi bug sản phẩm — không che bằng code test>
- **Người nên xử lý:** DevOps / dev sản phẩm / chủ tài khoản test
- **Bằng chứng:** <…>

## 4. Kết quả chạy lại CI

| Run | Nhánh | Spec | Kết quả |
|---|---|---|---|
| #<runId mới hoặc "đang chạy"> | `<ai-fix/…>` | <spec…> | ✅ / ❌ / ⏳ |

## 5. Việc còn lại cho tester (B4)

- [ ] Đọc diff PR <link> — kiểm từng cụm ở mục 3
- [ ] Xem video/screenshot của test đã sửa
- [ ] Chạy full suite nếu cần trước khi merge (AI chỉ chạy lại spec đã sửa)
- [ ] Cụm cần người xử lý: <danh sách + ai phụ trách>
- [ ] Merge PR khi đồng ý

## 6. Giới hạn & điều chưa chắc chắn

- <test không pass được ở local và lý do · batch bị loại do xung đột · mâu thuẫn dữ liệu giữa các file nếu có>

## 7. Phụ lục

- Nhật ký điều phối: `logs/orchestrator.md` · dữ liệu: `failures.json`, `clusters.json`, `fixes/*/result.json`
- Bằng chứng đã tải: `report/`, `reportportal/`, `ci-logs/`
````

## `pr_body.md` (rút gọn ≤ 60 dòng)

Tóm tắt (mục 1) + bảng cụm (mục 2) + danh sách file đổi + checklist tester (mục 5) + đường dẫn báo cáo đầy đủ. Dòng đầu: `🤖 PR do AI tạo — cần tester xác nhận trước khi merge.`
