# Project profile — doda-e2e (CI Auto-Fix)

> Ghi đè mặc định của `ci-auto-fix` / `ci-fixer`. Nguồn: `playwright.config.ts`, `.github/workflows/playwright.yml`, `package.json`, `.husky/pre-commit`, `claude.md`.

## 1. Chạy một spec ở local — cổng "pass local" (BẮT BUỘC trước khi commit/push)

**Chọn project theo đường dẫn spec** (giống logic của `playwright.yml`):

| Spec nằm ở | `--project` |
|---|---|
| `test-2g/…` | `test-2g` |
| mọi nơi khác (`tests/…`) | `all-cases` |

**Lệnh:**
```bash
env -u REPORT_PORTAL_API_KEY -u TEAMS_WEBHOOK_URL \
  npx playwright test --project=<all-cases|test-2g> <spec> --retries=0 --workers=1
```
- `env -u …` **bắt buộc**: `playwright.config.ts` tự đẩy kết quả lên **ReportPortal** và **MS Teams** khi hai biến này có giá trị — lần chạy thử của AI không được làm bẩn launch thật hay spam Teams.
- `--retries=0`: CI đang `retries: 1`, local phải đo đúng lần chạy đầu để biết fix có thật sự ổn định.
- Chạy theo từng spec (hoặc `-g "<tên test>"` khi spec chứa nhiều test mà chỉ vài test fail). **Không** chạy cả suite.
- Một spec có thể chạy vài phút (`slowMo: 500`, timeout 60s, `video: 'on'`) — không rút ngắn bằng cách hạ timeout.

**Chuẩn bị trước khi chạy:** `ci-fixer` làm việc trong **clone + worktree mới** — các thứ gitignore (`.env`, `.auth/`, `node_modules`, `test-data/data.json`) **không có sẵn**. Login cache nằm ở `<gốc project>/.auth/sessions/` nên **mỗi worktree cần có `.auth/` riêng**:
1. Trong clone (một lần): `npm ci` rồi `CI=true npm run cache:download`
2. Mỗi worktree: `cp -r <clone>/.auth <worktree>/.auth` và symlink `node_modules`. (Copy, không symlink `.auth` — nhiều lần chạy song song có thể ghi đè cùng file session.) Chạy tay ở máy local: copy thêm `.env`
Các thành phần cần có:
1. `npm ci`
2. `.env` hoặc biến môi trường: `BASE_URL`, `BASIC_AUTH_ID`, `BASIC_AUTH_PASS`, `DB_*`; `ENVIRONMENT` = môi trường của run lỗi (xem mục 4)
3. `npm run cache:download` (login cache + `data.csv` từ S3, cần `CI=true` và quyền AWS). Project `all-cases` phụ thuộc `setup data test` (`tests/global.setup.ts`) → bước này đọc CSV theo môi trường
4. Linux: Oracle Instant Client trong `LD_LIBRARY_PATH` (container CI đã cài sẵn)

**Số lần chạy để coi là pass:** 2 lần liên tiếp pass với test chỉ đọc/kiểm tra UI. Test **thay đổi dữ liệu một lần** (đăng ký thành viên, ứng tuyển, đổi trạng thái tuyển dụng, gửi message) → chạy **1 lần**; lần 2 có thể fail vì dữ liệu đã bị dùng, đó không phải lỗi của bản sửa — ghi rõ vào `notes`.

**Không chạy được ở local** (thiếu secrets/DB/mạng tới môi trường test, S3 không với tới) → `not-fixed`, **không push**.

## 2. Quality gate trước khi commit

Hook `.husky/pre-commit` chạy `npm run lint` và `npm run prettier` trên **toàn repo**. Thứ tự:
```bash
npx prettier --write <các file đã sửa>
npm run typecheck
npm run lint
npm run prettier
```
Cả 4 phải pass. **Cấm `--no-verify`.** Nếu hook fail vì vi phạm có sẵn ở file **không phải của mình** → dừng, báo `needs-human` (không sửa lan sang file khác để lách).

## 3. Phạm vi sửa

**Được sửa:** `tests/` · `test-2g/` · `pages/` · `helpers/` · `fixtures/` · `constants/` · `types/`

**Cấm sửa (cần người):** `.github/` · `playwright.config*.ts` · `tests/global.setup.ts` · `.env*` · `package*.json` · `Dockerfile` · `lib-image-docker/` · `.husky/` · `test-data/` (CSV tài khoản/dữ liệu, script) · `database/` · `data-creation/` · `config/` · `reports/` (⚠️ ở project này `reports/` là **source code** — Teams reporter — không phải thư mục output) · `claude.md`

**Quy ước bắt buộc của project:**
- **Không đổi tên `test.describe()` / `test()`** — số thứ tự đầu tên (`72.`, `5.`) là khoá tra `data[suite][case]` trong CSV. Đổi tên = mất dữ liệu test
- Giữ POM: locator ở constructor của Page class kế thừa `BasePage`; ưu tiên `getByRole`/`getByLabel`
- Mỗi hành động trong `test.step()`; giữ nguyên ngôn ngữ (tiếng Nhật) của tên test/step/thông báo hiện có
- **File dùng chung** — `pages/base-page.ts`, `pages/page-manager.ts`, `helpers/login.helper.ts`: sửa chỉ khi cụm lỗi trải ≥ 3 spec cùng nguyên nhân gốc, verify local trên ≥ 2 spec thuộc 2 thư mục khác nhau, và **ghi rõ trong báo cáo "ảnh hưởng toàn suite — tester chạy full trước khi merge"**
- Xác minh locator trên DOM thật bằng skill có sẵn `/playwright-cli` (theo `claude.md`: dùng playwright-cli để debug tương tác thay vì sửa code mò)

## 4. Chạy lại CI

- Workflow luôn là **`playwright.yml`** (tên "Playwright Tests"), kể cả khi run lỗi đến từ workflow scheduled (workflow đó chỉ nhận `testFile`)
- Input: `environment` ∈ {`st`, `staging`, `staging-2`, `testenv10`, `testenv08`} · `testFile` (nhiều spec cách nhau dấu cách)
- **Môi trường của run lỗi:** lấy từ `run.json → displayTitle`, đoạn sau ` - ` cuối cùng (`run-name` của workflow: `<actor> triggered on <ref> - <env>`). Không khớp danh sách trên → `st`
- ⚠️ Workflow chọn project bằng `grep -q "test-2g/"` trên **cả chuỗi** `testFile`: trộn spec `test-2g/` với `tests/` sẽ chạy tất cả bằng project `test-2g`. → **dispatch riêng hai lần** (một cho `tests/…`, một cho `test-2g/…`)
- Workflow dùng `environment:` của GitHub → secrets theo môi trường; job auto-fix cũng chạy với cùng environment (xem `.github/workflows/ai-autofix.yml`)

## 5. Thư mục báo cáo AI

`claude-report/ci-autofix/run_<runId>/` (đã `.gitignore`). **Không** dùng `reports/`.

## 6. Đặc thù / bẫy riêng

- Playwright **1.47.1**: report HTML **không** có `data/*.md`; kết quả nằm trong `index.html` (zip base64) — script `fetch` đã đọc được. Trường `file` của failure **tương đối theo `testDir` của project** (VD `login.spec.ts`, không có `tests/`) → dùng `Glob **/<file>` + `project` để tìm đúng spec
- CI `retries: 1`: test chỉ fail ở lần cuối mới vào danh sách fail; test pass ở retry (flaky) không có trong danh sách — nằm ngoài phạm vi lượt này
- Lỗi đăng nhập hàng loạt (`ログイン…`, "ログイン画面に留まっています", tài khoản từ CSV, login cache S3) → thường là tài khoản/dữ liệu/môi trường → `needs-human` trước khi nghĩ tới sửa code
- Link ReportPortal do step "Extract ReportPortal Launch Link" của `playwright.yml` in vào log; project RP: `doda-e2e` (st) hoặc `doda-e2e-<env>`

## 7. Tham chiếu trong các skill được chép sang — đọc để khỏi bị lệch

Các skill `analyze-flaky-tests`, `skills-flaky-test-analyzer`, `skills-locator-healer-agent`, `skills-smart-locator-agent` viết cho repo mẫu và nhắc tới vài file/quy tắc **không có** ở project này. Áp dụng như sau:

| Skill nhắc tới | Ở project này |
|---|---|
| `.claude/rules/locator_strategy.md` | Có (đã chép) — dùng nguyên |
| `.claude/rules/playwright_rules.md` · `selenium_rules.md` · `appium_rules.md` · `automation_rules.md` · `reporting_rules.md` | **Không có — bỏ qua.** Quy ước của project nằm ở `claude.md` và mục 3 file này |
| Quy tắc "headed mode / viewport 1600×750 khi debug", "Allure / screenshot cuối mọi test" | **Không áp dụng.** CI chạy headless theo `playwright.config.ts`; báo cáo là ReportPortal + Playwright HTML, không dùng Allure |
| `skills-ui-debug-agent`, Playwright MCP | Không có — dùng skill `/playwright-cli` của project để inspect DOM |
| Checkpoint "chờ user xác nhận" ở Bước 3 của `analyze-flaky-tests` | Bỏ — đã được duyệt trước theo guardrail của `ci-fixer` |
