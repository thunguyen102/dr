---
name: skills-locator-agent
description: Skill locator hợp nhất cho UI automation (Playwright, Selenium, Appium) — GENERATE sinh locator ổn định cho element mới hoặc rà locator mong manh, HEAL phát hiện và sửa locator hỏng khi test fail do DOM thay đổi. Luôn inspect DOM thật, không đoán.
---

# Locator Agent

Một skill cho mọi việc liên quan tới locator. Thứ tự ưu tiên và quy tắc ổn định là **chung** cho cả hai mode, lấy từ [`.claude/rules/locator_strategy.md`](../../rules/locator_strategy.md) — file đó là nguồn gốc, skill này không lặp lại bảng ưu tiên tổng.

## 1. Chọn mode

| Mode | Khi nào | Input | Output |
|---|---|---|---|
| **GENERATE** | Viết test mới, thêm element mới vào Page Object, review/migrate locator | Element trên DOM / UI hierarchy | Locator chính + fallback + lý do |
| **HEAL — reactive** | Test fail: `TimeoutError` chờ element, `element not found`, `detached`, `strict mode violation`, thao tác nhầm element | Error log + stack trace + screenshot/trace | Locator đã thay trong Page Object + test pass lại |
| **HEAL — proactive (scan)** | UI vừa đổi / sau deploy, chưa có test fail | Page Object + URL | Danh sách locator hỏng · mong manh · sai element, rồi sửa |

Proactive không có error log để lần theo → trích **toàn bộ** locator trong Page Object, đưa browser về đúng trạng thái chứa element rồi đối chiếu từng cái. Bắt được cả locator **mong manh** (còn chạy nhưng bám thuộc tính dễ đổi) và **sai element** (match đúng 1 element nhưng không phải element cần — test vẫn xanh mà thao tác nhầm chỗ).

## 2. Nguyên tắc chung (cả hai mode)

1. **Inspect DOM thật, KHÔNG đoán.** Nguồn hợp lệ: Playwright MCP (`browser_navigate` → `browser_snapshot`), page snapshot/trace trong report, screenshot + DOM đã tải về, hoặc công cụ inspect của project (VD skill `/playwright-cli`). Không có nguồn nào → không sinh/sửa locator, báo lại.
2. Đưa trang về **đúng trạng thái** chứa element (đã login, đã mở modal, đã có data…) trước khi inspect.
3. Ưu tiên theo `locator_strategy.md`: Aria/accessibility → `data-testid` → `id`/`name` ổn định → hàm semantic của framework → CSS → XPath tương đối.
4. Cấm: class động / hash, `nth-child`/`nth-of-type` khi có lựa chọn tốt hơn, ID tự sinh, XPath tuyệt đối theo vị trí.
5. Giữ đúng quy ước của project: locator nằm trong Page Object, không rải trong spec.

## 3. Mode GENERATE

1. Inspect element và vùng xung quanh (label, role, container có ngữ nghĩa).
2. Liệt kê thuộc tính ổn định; loại thuộc tính động.
3. Sinh locator theo thứ tự ưu tiên của framework (mục 5). Element trùng lặp → **scope** theo container có ngữ nghĩa (`getByRole('dialog').getByRole('button', { name: '保存' })`) thay vì index.
4. Validate (mục 6).
5. Trả về:
   - **Primary** — locator ổn định nhất
   - **Fallback** — phương án khi primary hỏng (khác loại thuộc tính với primary)
   - **Lý do** — vì sao chọn, rủi ro còn lại

## 4. Mode HEAL

**Locator bị coi là hỏng khi:** không match element nào · match > 1 (`strict mode violation`) · element bị detached · match nhầm element (text/vai trò/vị trí khác kỳ vọng).

1. **Phân tích lỗi** — từ log/stack trace xác định locator nào hỏng, file Page Object + dòng. (Proactive: trích toàn bộ locator của Page Object.)
2. **Inspect DOM hiện tại** ở đúng trạng thái của bước test fail; xem screenshot/trace lúc fail.
3. **So sánh** locator cũ với DOM mới → thuộc tính nào đã đổi (text, role, testid, cấu trúc).
4. **Phân biệt trước khi sửa:** UI đổi hợp lệ (đổi nhãn, đổi cấu trúc) → sửa locator. Element **biến mất / sai nghiệp vụ** (bug sản phẩm, trang lỗi, chưa login) → **không** sửa locator để che lỗi; báo lại kèm bằng chứng.
5. **Sinh locator thay thế** theo Mode GENERATE (bước 3–4).
6. **Thay trong Page Object**, giữ tên thuộc tính/method để không lan sửa sang spec.
7. **Chạy lại test** — phải pass; locator không được làm yếu assertion hay thêm `waitForTimeout`.

## 5. Theo framework

**Playwright** — `getByRole()` (kèm `name`) → `getByLabel()` → `getByPlaceholder()` → `getByText()` → `getByTestId()` → `locator(css)` → XPath.
```typescript
page.getByRole('button', { name: 'Submit' })
page.getByLabel('Email')
page.getByRole('dialog').getByRole('button', { name: '保存' })   // scope thay vì nth()
```
Dùng auto-waiting của locator + web-first assertion (`expect(locator).toBeVisible()`), không `waitForTimeout`.

**Selenium** — `id` → `data-testid` → `name` → `cssSelector` → XPath tương đối.
```java
driver.findElement(By.id("login-button"));
driver.findElement(By.cssSelector("button[data-testid='submit-btn']"));
```

**Appium** — `accessibility id` → `resource-id` → `id` → iOS predicate / class chain → XPath.
```java
driver.findElement(AppiumBy.accessibilityId("login_button"));
driver.findElement(AppiumBy.iOSNsPredicateString("label == 'Login'"));
```

## 6. Checklist xác minh (bắt buộc trước khi đưa vào code)

- [ ] Match **đúng 1** element trong scope
- [ ] Đúng element cần (text / role / thuộc tính khớp), visible và tương tác được
- [ ] Vẫn đúng sau reload / navigate lại
- [ ] Ổn định qua các trạng thái trang (loading, có data, không data)
- [ ] Không dùng class động, ID tự sinh, XPath vị trí
- [ ] HEAL: test chạy lại pass

## 7. Dùng cùng skill khác

| Ngữ cảnh | Skill |
|---|---|
| Test flaky, cần tìm root cause trước | `analyze-flaky-tests` → khi root cause là locator thì quay về skill này |
| Sửa test fail trên CI | `ci-fixer` (trong `/ci-auto-fix`) dùng Mode HEAL — reactive, không có checkpoint chờ user |
